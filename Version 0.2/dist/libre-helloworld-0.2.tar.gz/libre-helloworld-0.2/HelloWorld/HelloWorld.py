def HelloWorld(text):
    print(text)

def helloWorld(text):
    print(text)

def Helloworld(text):
    print(text)

def helloworld(text):
    print(text)