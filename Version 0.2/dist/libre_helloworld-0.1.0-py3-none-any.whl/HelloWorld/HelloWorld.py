def HelloWorld(text):
    print(text)
